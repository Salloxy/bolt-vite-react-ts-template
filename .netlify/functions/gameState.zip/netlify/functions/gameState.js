var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var gameState_exports = {};
__export(gameState_exports, {
  canPlaceCardInHandServer: () => canPlaceCardInHandServer,
  createNewGame: () => createNewGame,
  handleGameEvaluation: () => handleGameEvaluation,
  matchmakingQueue: () => matchmakingQueue,
  rooms: () => rooms
});
module.exports = __toCommonJS(gameState_exports);
var import_utils = require("../src/lib/utils");
var import_pokerEvaluator = require("../src/lib/pokerEvaluator");
const rooms = /* @__PURE__ */ new Map();
const matchmakingQueue = [];
const initializePlayerForServer = (id) => ({
  id,
  hands: Array(5).fill(null).map(() => ({ cards: Array(5).fill(null) }))
});
const dealInitialCardsServer = (player, deck) => {
  const newHands = player.hands.map((hand) => {
    const card = deck.pop();
    if (!card)
      return hand;
    return { ...hand, cards: [{ ...card, hidden: false }, null, null, null, null] };
  });
  return { player: { ...player, hands: newHands }, deck };
};
function createNewGame(player1Id, player2Id) {
  const roomId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  let deck = (0, import_utils.shuffleDeck)((0, import_utils.createDeck)());
  let p1 = initializePlayerForServer(player1Id);
  let p2 = initializePlayerForServer(player2Id);
  const dealt1 = dealInitialCardsServer(p1, deck);
  p1 = dealt1.player;
  deck = dealt1.deck;
  const dealt2 = dealInitialCardsServer(p2, deck);
  p2 = dealt2.player;
  deck = dealt2.deck;
  const initialGameState = {
    id: roomId,
    deck,
    players: [p1, p2],
    currentPlayerId: player1Id,
    gamePhase: "playing",
    turnNumber: 0,
    placementRuleActive: true,
    heldCard: null
  };
  const room = {
    id: roomId,
    players: [
      { playerId: player1Id, playerNumber: 1 },
      { playerId: player2Id, playerNumber: 2 }
    ],
    gameState: initialGameState,
    rematchRequests: /* @__PURE__ */ new Set()
  };
  rooms.set(roomId, room);
  return room;
}
function canPlaceCardInHandServer(player, handIndex, targetSlot) {
  if (targetSlot < 0 || targetSlot > 4)
    return false;
  const counts = player.hands.map((h) => h.cards.filter((c) => c !== null).length);
  if (counts[handIndex] !== targetSlot)
    return false;
  const newCount = counts[handIndex] + 1;
  if (newCount === 3) {
    return counts.every((c) => c >= 2);
  }
  if (newCount === 4) {
    return counts.every((c) => c >= 3);
  }
  if (newCount === 5) {
    return counts.every((c) => c >= 4);
  }
  return true;
}
function handleGameEvaluation(room) {
  room.gameState.players = room.gameState.players.map((player) => ({
    ...player,
    hands: player.hands.map((hand) => ({
      ...hand,
      cards: hand.cards.map((card) => card ? { ...card, hidden: false } : null)
    }))
  }));
  room.gameState.gamePhase = "evaluation";
  const finalPlayers = room.gameState.players.map((p) => ({
    ...p,
    hands: p.hands.map((h) => ({ ...h, evaluation: (0, import_pokerEvaluator.evaluateHand)(h.cards) }))
  }));
  room.gameState.players = finalPlayers;
  let p1Wins = 0;
  let p2Wins = 0;
  const individualWinners = Array(5).fill(null);
  for (let i = 0; i < 5; i++) {
    const ev1 = finalPlayers[0].hands[i].evaluation;
    const ev2 = finalPlayers[1].hands[i].evaluation;
    if (ev1 && ev2) {
      const cmp = (0, import_pokerEvaluator.compareEvaluatedHands)(ev1, ev2);
      if (cmp > 0) {
        p1Wins++;
        individualWinners[i] = finalPlayers[0].id;
      } else if (cmp < 0) {
        p2Wins++;
        individualWinners[i] = finalPlayers[1].id;
      } else {
        individualWinners[i] = "Tie";
      }
    }
  }
  room.gameState.individualHandWinners = individualWinners;
  room.gameState.winnerMessage = p1Wins > p2Wins ? `${finalPlayers[0].id} wins (${p1Wins} to ${p2Wins})` : p2Wins > p1Wins ? `${finalPlayers[1].id} wins (${p2Wins} to ${p1Wins})` : `Tie game (${p1Wins} to ${p2Wins})`;
  room.gameState.gamePhase = "gameOver";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  canPlaceCardInHandServer,
  createNewGame,
  handleGameEvaluation,
  matchmakingQueue,
  rooms
});
