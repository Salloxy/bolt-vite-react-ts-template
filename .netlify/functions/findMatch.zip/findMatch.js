var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/findMatch.ts
var findMatch_exports = {};
__export(findMatch_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(findMatch_exports);

// src/lib/utils.ts
var SUITS = ["H", "D", "C", "S"];
var RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"];
var createDeck = () => {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, id: `${rank}${suit}` });
    }
  }
  return deck;
};
var shuffleDeck = (deck) => {
  const shuffledDeck = [...deck];
  for (let i = shuffledDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledDeck[i], shuffledDeck[j]] = [shuffledDeck[j], shuffledDeck[i]];
  }
  return shuffledDeck;
};

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();
var matchmakingQueue = [];
var initializePlayerForServer = (id) => ({
  id,
  hands: Array(5).fill(null).map(() => ({ cards: Array(5).fill(null) }))
});
var dealInitialCardsServer = (player, deck) => {
  const newHands = player.hands.map((hand) => {
    const card = deck.pop();
    if (!card) return hand;
    return { ...hand, cards: [{ ...card, hidden: false }, null, null, null, null] };
  });
  return { player: { ...player, hands: newHands }, deck };
};
function createNewGame(player1Id, player2Id) {
  const roomId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  let deck = shuffleDeck(createDeck());
  let p1 = initializePlayerForServer(player1Id);
  let p2 = initializePlayerForServer(player2Id);
  const dealt1 = dealInitialCardsServer(p1, deck);
  p1 = dealt1.player;
  deck = dealt1.deck;
  const dealt2 = dealInitialCardsServer(p2, deck);
  p2 = dealt2.player;
  deck = dealt2.deck;
  const initialGameState = {
    id: roomId,
    deck,
    players: [p1, p2],
    currentPlayerId: player1Id,
    gamePhase: "playing",
    turnNumber: 0,
    placementRuleActive: true,
    heldCard: null
  };
  const room = {
    id: roomId,
    players: [
      { playerId: player1Id, playerNumber: 1 },
      { playerId: player2Id, playerNumber: 2 }
    ],
    gameState: initialGameState,
    rematchRequests: /* @__PURE__ */ new Set()
  };
  rooms.set(roomId, room);
  return room;
}

// server/findMatch.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { playerId } = payload;
  if (!playerId) {
    return { statusCode: 400, body: "Missing playerId" };
  }
  const inQueue = matchmakingQueue.includes(playerId);
  const inGame = Array.from(rooms.values()).some(
    (r) => r.players.some((p) => p.playerId === playerId)
  );
  if (!inQueue && !inGame) {
    matchmakingQueue.push(playerId);
  }
  if (matchmakingQueue.length >= 2) {
    const p1 = matchmakingQueue.shift();
    const p2 = matchmakingQueue.shift();
    const room = createNewGame(p1, p2);
    return {
      statusCode: 200,
      body: JSON.stringify({ matched: true, gameId: room.id, gameState: room.gameState })
    };
  }
  return { statusCode: 200, body: JSON.stringify({ matched: false }) };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
