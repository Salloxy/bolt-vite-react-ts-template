var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/declineRematch.ts
var declineRematch_exports = {};
__export(declineRematch_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(declineRematch_exports);

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();

// server/declineRematch.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { gameId, decliningPlayerId } = payload;
  if (!gameId || !decliningPlayerId) {
    return { statusCode: 400, body: "Missing gameId or decliningPlayerId" };
  }
  const room = rooms.get(gameId);
  if (!room) {
    return { statusCode: 404, body: "Game not found or already concluded." };
  }
  if (room.gameState.gamePhase !== "gameOver" && room.gameState.rematchState !== "offer_sent" && room.gameState.rematchState !== "offer_received") {
    room.gameState.rematchState = "none";
    room.gameState.rematchAgreedCount = 0;
    delete room.rematchRequests;
    return {
      statusCode: 200,
      // Or 400 if strict about when decline is valid
      body: JSON.stringify({ message: "No active rematch offer to decline or game not in correct state.", gameState: room.gameState })
    };
  }
  console.log(`Player ${decliningPlayerId} declined rematch for game ${gameId}`);
  room.gameState.rematchState = "declined_by_opponent";
  room.gameState.rematchAgreedCount = 0;
  if (room.rematchRequests) {
    room.rematchRequests.clear();
  }
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Rematch declined.",
      gameState: room.gameState,
      rematchState: room.gameState.rematchState,
      // Send updated state
      rematchAgreedCount: room.gameState.rematchAgreedCount
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
