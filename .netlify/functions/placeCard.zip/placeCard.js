var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/placeCard.ts
var placeCard_exports = {};
__export(placeCard_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(placeCard_exports);

// src/lib/utils.ts
var getRankValue = (rank) => {
  if (rank === "A") return 14;
  if (rank === "K") return 13;
  if (rank === "Q") return 12;
  if (rank === "J") return 11;
  if (rank === "T") return 10;
  return parseInt(rank, 10);
};

// src/lib/pokerEvaluator.ts
var sortCards = (cards) => {
  return [...cards].sort((a, b) => getRankValue(b.rank) - getRankValue(a.rank));
};
var getRankCounts = (cards) => {
  const counts = {};
  for (const card of cards) {
    counts[card.rank] = (counts[card.rank] || 0) + 1;
  }
  return counts;
};
var isFlush = (cards) => {
  if (cards.length !== 5) return { flush: false };
  const firstSuit = cards[0].suit;
  const flush = cards.every((card) => card.suit === firstSuit);
  return { flush, suit: flush ? firstSuit : void 0 };
};
var isStraight = (cards) => {
  if (cards.length !== 5) return { straight: false };
  const sortedRanks = sortCards(cards).map((card) => getRankValue(card.rank));
  const isAceLow = sortedRanks[0] === 14 && sortedRanks[1] === 5 && sortedRanks[2] === 4 && sortedRanks[3] === 3 && sortedRanks[4] === 2;
  if (isAceLow) return { straight: true, highRank: "5" };
  for (let i = 0; i < sortedRanks.length - 1; i++) {
    if (sortedRanks[i] !== sortedRanks[i + 1] + 1) {
      return { straight: false };
    }
  }
  return { straight: true, highRank: cards[0].rank };
};
var evaluateHand = (hand) => {
  const validCards = hand.filter((card) => card !== null);
  if (validCards.length !== 5) {
    return null;
  }
  const sortedHand = sortCards(validCards);
  const rankCounts = getRankCounts(sortedHand);
  const { flush, suit: flushSuit } = isFlush(sortedHand);
  const { straight, highRank: straightHighRank } = isStraight(sortedHand);
  const ranksPresent = Object.keys(rankCounts);
  const counts = Object.values(rankCounts);
  if (straight && flush) {
    let desc = "";
    if (straightHighRank === "A") {
      desc = "Royal Flush";
    } else if (straightHighRank === "5") {
      desc = "Steel Wheel (5 High Straight Flush)";
    } else {
      desc = `${straightHighRank} High Straight Flush`;
    }
    return {
      rank: 8 /* STRAIGHT_FLUSH */,
      values: [straightHighRank],
      description: desc
    };
  }
  if (counts.includes(4)) {
    const fourRank = ranksPresent.find((r) => rankCounts[r] === 4);
    const kicker = ranksPresent.find((r) => rankCounts[r] === 1);
    return { rank: 7 /* FOUR_OF_A_KIND */, values: [fourRank, kicker], description: `Four of a Kind, ${fourRank}s` };
  }
  if (counts.includes(3) && counts.includes(2)) {
    const threeRank = ranksPresent.find((r) => rankCounts[r] === 3);
    const pairRank = ranksPresent.find((r) => rankCounts[r] === 2);
    return { rank: 6 /* FULL_HOUSE */, values: [threeRank, pairRank], description: `Full House, ${threeRank}s over ${pairRank}s` };
  }
  if (flush) {
    return { rank: 5 /* FLUSH */, values: sortedHand.map((c) => c.rank), description: `${flushSuit} Flush, ${sortedHand[0].rank} high` };
  }
  if (straight) {
    return { rank: 4 /* STRAIGHT */, values: [straightHighRank], description: `${straightHighRank} High Straight` };
  }
  if (counts.includes(3)) {
    const threeRank = ranksPresent.find((r) => rankCounts[r] === 3);
    const kickers = sortedHand.filter((c) => c.rank !== threeRank).map((c) => c.rank).slice(0, 2);
    return { rank: 3 /* THREE_OF_A_KIND */, values: [threeRank, ...kickers], description: `Three of a Kind, ${threeRank}s` };
  }
  const pairs = ranksPresent.filter((r) => rankCounts[r] === 2);
  if (pairs.length === 2) {
    const sortedPairs = pairs.sort((a, b) => getRankValue(b) - getRankValue(a));
    const kicker = sortedHand.find((c) => !pairs.includes(c.rank)).rank;
    return { rank: 2 /* TWO_PAIR */, values: [...sortedPairs, kicker], description: `Two Pair, ${sortedPairs[0]}s and ${sortedPairs[1]}s` };
  }
  if (pairs.length === 1) {
    const pairRank = pairs[0];
    const kickers = sortedHand.filter((c) => c.rank !== pairRank).map((c) => c.rank).slice(0, 3);
    return { rank: 1 /* ONE_PAIR */, values: [pairRank, ...kickers], description: `Pair of ${pairRank}s` };
  }
  return { rank: 0 /* HIGH_CARD */, values: sortedHand.map((c) => c.rank), description: `${sortedHand[0].rank} High` };
};
var compareEvaluatedHands = (handA, handB) => {
  if (handA.rank > handB.rank) return 1;
  if (handA.rank < handB.rank) return -1;
  for (let i = 0; i < handA.values.length; i++) {
    if (i >= handB.values.length) return 1;
    const valueA = getRankValue(handA.values[i]);
    const valueB = getRankValue(handB.values[i]);
    if (valueA > valueB) return 1;
    if (valueA < valueB) return -1;
  }
  if (handB.values.length > handA.values.length) return -1;
  return 0;
};

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();
function canPlaceCardInHandServer(player, handIndex, targetSlot) {
  if (targetSlot < 0 || targetSlot > 4) return false;
  const counts = player.hands.map((h) => h.cards.filter((c) => c !== null).length);
  if (counts[handIndex] !== targetSlot) return false;
  const newCount = counts[handIndex] + 1;
  if (newCount === 3) {
    return counts.every((c) => c >= 2);
  }
  if (newCount === 4) {
    return counts.every((c) => c >= 3);
  }
  if (newCount === 5) {
    return counts.every((c) => c >= 4);
  }
  return true;
}
function handleGameEvaluation(room) {
  room.gameState.players = room.gameState.players.map((player) => ({
    ...player,
    hands: player.hands.map((hand) => ({
      ...hand,
      cards: hand.cards.map((card) => card ? { ...card, hidden: false } : null)
    }))
  }));
  room.gameState.gamePhase = "evaluation";
  const finalPlayers = room.gameState.players.map((p) => ({
    ...p,
    hands: p.hands.map((h) => ({ ...h, evaluation: evaluateHand(h.cards) }))
  }));
  room.gameState.players = finalPlayers;
  let p1Wins = 0;
  let p2Wins = 0;
  const individualWinners = Array(5).fill(null);
  for (let i = 0; i < 5; i++) {
    const ev1 = finalPlayers[0].hands[i].evaluation;
    const ev2 = finalPlayers[1].hands[i].evaluation;
    if (ev1 && ev2) {
      const cmp = compareEvaluatedHands(ev1, ev2);
      if (cmp > 0) {
        p1Wins++;
        individualWinners[i] = finalPlayers[0].id;
      } else if (cmp < 0) {
        p2Wins++;
        individualWinners[i] = finalPlayers[1].id;
      } else {
        individualWinners[i] = "Tie";
      }
    }
  }
  room.gameState.individualHandWinners = individualWinners;
  room.gameState.winnerMessage = p1Wins > p2Wins ? `${finalPlayers[0].id} wins (${p1Wins} to ${p2Wins})` : p2Wins > p1Wins ? `${finalPlayers[1].id} wins (${p2Wins} to ${p1Wins})` : `Tie game (${p1Wins} to ${p2Wins})`;
  room.gameState.gamePhase = "gameOver";
}

// server/placeCard.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { gameId, playerId, handIndex, card } = payload;
  if (!gameId || !playerId || handIndex === void 0 || !card) {
    return { statusCode: 400, body: "Missing gameId, playerId, handIndex, or card" };
  }
  const room = rooms.get(gameId);
  if (!room) {
    return { statusCode: 404, body: "Game not found" };
  }
  if (room.gameState.currentPlayerId !== playerId || !room.gameState.heldCard || room.gameState.heldCard.id !== card.id) {
    return { statusCode: 400, body: "Invalid action, not your turn, or card mismatch." };
  }
  const playerState = room.gameState.players.find((p) => p.id === playerId);
  if (!playerState) {
    return { statusCode: 404, body: "Player not found in game" };
  }
  const targetHand = playerState.hands[handIndex];
  if (!targetHand) {
    return { statusCode: 400, body: "Invalid hand index." };
  }
  const firstEmptySlot = targetHand.cards.findIndex((c) => c === null);
  if (firstEmptySlot === -1) {
    return { statusCode: 400, body: "Hand is full." };
  }
  if (!canPlaceCardInHandServer(playerState, handIndex, firstEmptySlot)) {
    return { statusCode: 400, body: "Placement restriction: Cannot place card in this hand yet." };
  }
  targetHand.cards[firstEmptySlot] = card;
  if (firstEmptySlot === 4) {
    targetHand.cards[firstEmptySlot].hidden = true;
  }
  room.gameState.heldCard = null;
  const allHandsFull = room.gameState.players.every(
    (p) => p.hands.every((h) => h.cards.filter((c) => c !== null).length === 5)
  );
  if (allHandsFull) {
    room.gameState.gamePhase = "evaluation";
    handleGameEvaluation(room);
  } else {
    const currentPlayerIndex = room.players.findIndex((p) => p.playerId === playerId);
    room.gameState.currentPlayerId = room.players[(currentPlayerIndex + 1) % room.players.length].playerId;
    room.gameState.turnNumber++;
  }
  return {
    statusCode: 200,
    body: JSON.stringify({ gameState: room.gameState })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
