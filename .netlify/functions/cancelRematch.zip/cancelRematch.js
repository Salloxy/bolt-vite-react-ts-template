var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/cancelRematch.ts
var cancelRematch_exports = {};
__export(cancelRematch_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(cancelRematch_exports);

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();

// server/cancelRematch.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { gameId, cancellingPlayerId } = payload;
  if (!gameId || !cancellingPlayerId) {
    return { statusCode: 400, body: "Missing gameId or cancellingPlayerId" };
  }
  const room = rooms.get(gameId);
  if (!room || !room.rematchRequests || !room.rematchRequests.has(cancellingPlayerId)) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: "No active rematch request to cancel for this player or game not found.", gameState: room?.gameState })
    };
  }
  console.log(`Player ${cancellingPlayerId} cancelled rematch request for game ${gameId}`);
  room.rematchRequests.delete(cancellingPlayerId);
  room.gameState.rematchAgreedCount = room.rematchRequests.size;
  if (room.gameState.gamePhase === "gameOver") {
    room.gameState.rematchState = room.rematchRequests.size > 0 ? "offer_sent" : "can_offer";
  } else {
    room.gameState.rematchState = "none";
  }
  return {
    statusCode: 200,
    body: JSON.stringify({
      message: "Rematch request cancelled.",
      gameState: room.gameState,
      rematchState: room.gameState.rematchState,
      rematchAgreedCount: room.gameState.rematchAgreedCount
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
