var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var import_express = __toESM(require("express"), 1);
var import_http = __toESM(require("http"), 1);
var import_socket = require("socket.io");
var import_utils = require("../src/lib/utils");
var import_pokerEvaluator = require("../src/lib/pokerEvaluator");
const app = (0, import_express.default)();
const server = import_http.default.createServer(app);
const io = new import_socket.Server(server, {
  cors: {
    origin: "http://localhost:5173",
    // Vite dev server default
    methods: ["GET", "POST"]
  }
});
const PORT = process.env.PORT || 3e3;
const REMATCH_WINDOW_MS = 1e4;
const rooms = /* @__PURE__ */ new Map();
const matchmakingQueue = [];
const initializePlayerForServer = (id) => ({
  id,
  hands: Array(5).fill(null).map(() => ({ cards: Array(5).fill(null) }))
});
const createNewGame = (player1Socket, player2Socket) => {
  const roomId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  let player1ServerObj = initializePlayerForServer(player1Socket.id);
  let player2ServerObj = initializePlayerForServer(player2Socket.id);
  let serverDeck = (0, import_utils.shuffleDeck)((0, import_utils.createDeck)());
  const dealInitialCardsServer = (player, currentDeck) => {
    const updatedPlayerHands = player.hands.map((hand) => {
      const cardToDeal = currentDeck.pop();
      const dealtCard = cardToDeal ? { ...cardToDeal, hidden: false } : null;
      return dealtCard ? { ...hand, cards: [dealtCard, null, null, null, null] } : hand;
    });
    return { updatedPlayer: { ...player, hands: updatedPlayerHands }, updatedDeck: currentDeck };
  };
  const p1Result = dealInitialCardsServer(player1ServerObj, serverDeck);
  player1ServerObj = p1Result.updatedPlayer;
  serverDeck = p1Result.updatedDeck;
  const p2Result = dealInitialCardsServer(player2ServerObj, serverDeck);
  player2ServerObj = p2Result.updatedPlayer;
  serverDeck = p2Result.updatedDeck;
  const initialGameState = {
    id: roomId,
    deck: serverDeck,
    players: [player1ServerObj, player2ServerObj],
    currentPlayerId: player1Socket.id,
    // Player 1 (first to connect to match) starts
    gamePhase: "playing",
    // Start directly in playing phase after initial deal
    turnNumber: 0,
    placementRuleActive: true,
    heldCard: null
  };
  const room = {
    id: roomId,
    players: [
      { socketId: player1Socket.id, playerNumber: 1 },
      { socketId: player2Socket.id, playerNumber: 2 }
    ],
    gameState: initialGameState,
    turnTimerDuration: 3e4
    // 30 seconds
  };
  rooms.set(roomId, room);
  player1Socket.join(roomId);
  player2Socket.join(roomId);
  console.log(`Game room ${roomId} created for ${player1Socket.id} and ${player2Socket.id}`);
  return room;
};
io.on("connection", (socket) => {
  console.log("A user connected:", socket.id);
  const clearTurnTimer = (room) => {
    if (room.turnTimerId) {
      clearTimeout(room.turnTimerId);
      delete room.turnTimerId;
    }
    delete room.gameState.turnStartTime;
    delete room.gameState.turnTimerEndsAt;
  };
  const startTurnTimer = (room) => {
    clearTurnTimer(room);
    if (room.gameState.gamePhase !== "playing" || !room.gameState.currentPlayerId) {
      return;
    }
    const currentPlayerSocketId = room.gameState.currentPlayerId;
    room.gameState.turnStartTime = Date.now();
    room.gameState.turnTimerEndsAt = Date.now() + room.turnTimerDuration;
    console.log(`Starting turn timer (${room.turnTimerDuration / 1e3}s) for player ${currentPlayerSocketId} in room ${room.id}`);
    room.turnTimerId = setTimeout(() => {
      if (!rooms.has(room.id) || room.gameState.currentPlayerId !== currentPlayerSocketId) {
        return;
      }
      console.log(`Turn timer expired for player ${currentPlayerSocketId} in room ${room.id}`);
      const timedOutPlayerSocket = io.sockets.sockets.get(currentPlayerSocketId);
      if (timedOutPlayerSocket) {
        timedOutPlayerSocket.emit("turnTimeout", { gameId: room.id, playerId: currentPlayerSocketId });
      }
      const currentPlayerIndex = room.players.findIndex((p) => p.socketId === currentPlayerSocketId);
      const nextPlayerIndex = (currentPlayerIndex + 1) % room.players.length;
      room.gameState.currentPlayerId = room.players[nextPlayerIndex].socketId;
      room.gameState.turnNumber++;
      room.gameState.heldCard = null;
      console.log(`Switched to player ${room.gameState.currentPlayerId} due to timeout in room ${room.id}`);
      startTurnTimer(room);
      io.to(room.id).emit("gameStateUpdate", room.gameState);
    }, room.turnTimerDuration);
    io.to(room.id).emit("gameStateUpdate", room.gameState);
  };
  const clearRoomRematchTimer = (room) => {
    if (room.rematchInfo?.timerId) {
      clearTimeout(room.rematchInfo.timerId);
      delete room.rematchInfo.timerId;
    }
  };
  socket.on("findMatch", () => {
    console.log(`Player ${socket.id} is looking for a match.`);
    if (matchmakingQueue.find((s) => s.id === socket.id) || Array.from(rooms.values()).find((r) => r.players.some((p) => p.socketId === socket.id))) {
      socket.emit("error", "Already in queue or game.");
      return;
    }
    matchmakingQueue.push(socket);
    if (matchmakingQueue.length >= 2) {
      const player1 = matchmakingQueue.shift();
      const player2 = matchmakingQueue.shift();
      const room = createNewGame(player1, player2);
      io.to(room.id).emit("gameStart", room.gameState);
      startTurnTimer(room);
    } else {
      socket.emit("message", "Waiting for another player...");
    }
  });
  socket.on("drawCard", ({ gameId, playerId }) => {
    const room = rooms.get(gameId);
    if (!room || room.gameState.currentPlayerId !== playerId || room.gameState.heldCard) {
      socket.emit("error", "Invalid action or not your turn or card already held.");
      return;
    }
    if (room.gameState.deck.length === 0) {
      socket.emit("error", "Deck is empty.");
      return;
    }
    const drawnCard = room.gameState.deck.pop();
    room.gameState.heldCard = drawnCard;
    socket.emit("playerDrewCard", { card: drawnCard });
    socket.emit("gameStateUpdate", room.gameState);
    const opponentSocketId = room.players.find((p) => p.socketId !== playerId)?.socketId;
    if (opponentSocketId) {
      const opponentGameState = JSON.parse(JSON.stringify(room.gameState));
      if (opponentGameState.currentPlayerId === playerId) {
        opponentGameState.heldCard = null;
      }
      io.to(opponentSocketId).emit("gameStateUpdate", opponentGameState);
    }
    console.log(`Player ${playerId} in room ${gameId} drew ${drawnCard.id}`);
  });
  socket.on("placeCard", ({ gameId, playerId, handIndex, card }) => {
    const room = rooms.get(gameId);
    if (!room || room.gameState.currentPlayerId !== playerId || !room.gameState.heldCard || room.gameState.heldCard.id !== card.id) {
      socket.emit("error", "Invalid action, not your turn, or card mismatch.");
      return;
    }
    clearTurnTimer(room);
    const playerState = room.gameState.players.find((p) => p.id === playerId);
    if (!playerState)
      return;
    const targetHand = playerState.hands[handIndex];
    if (!targetHand) {
      socket.emit("error", "Invalid hand index.");
      return;
    }
    const firstEmptySlot = targetHand.cards.findIndex((c) => c === null);
    if (firstEmptySlot === -1) {
      socket.emit("error", "Hand is full.");
      return;
    }
    if (!canPlaceCardInHandServer(playerState, handIndex, firstEmptySlot)) {
      socket.emit("error", "Placement restriction: Cannot place card in this hand yet.");
      return;
    }
    targetHand.cards[firstEmptySlot] = card;
    if (firstEmptySlot === 4) {
      targetHand.cards[firstEmptySlot].hidden = true;
    }
    room.gameState.heldCard = null;
    const allHandsFull = room.gameState.players.every((p) => p.hands.every((h) => h.cards.filter((c) => c !== null).length === 5));
    if (allHandsFull) {
      room.gameState.gamePhase = "evaluation";
      clearTurnTimer(room);
    } else {
      const currentPlayerIndex = room.players.findIndex((p) => p.socketId === playerId);
      room.gameState.currentPlayerId = room.players[(currentPlayerIndex + 1) % room.players.length].socketId;
      room.gameState.turnNumber++;
      startTurnTimer(room);
    }
    io.to(gameId).emit("gameStateUpdate", room.gameState);
    console.log(`Player ${playerId} in room ${gameId} placed ${card.id} in hand ${handIndex}`);
    if (room.gameState.gamePhase === "evaluation") {
      handleGameEvaluation(room);
    }
  });
  const handleGameEvaluation = (room) => {
    clearTurnTimer(room);
    console.log(`Evaluating game ${room.id}`);
    const playersWithRevealedCards = room.gameState.players.map((player) => ({
      ...player,
      hands: player.hands.map((hand) => ({
        ...hand,
        cards: hand.cards.map((card) => card ? { ...card, hidden: false } : null)
      }))
    }));
    const handEvalResults = {
      p1Wins: 0,
      p2Wins: 0,
      individualWinners: Array(5).fill(null)
    };
    const finalPlayerStates = playersWithRevealedCards.map((p) => ({
      ...p,
      hands: p.hands.map((h) => ({ ...h, evaluation: (0, import_pokerEvaluator.evaluateHand)(h.cards) }))
    }));
    for (let i = 0; i < 5; i++) {
      const evalP1 = finalPlayerStates[0].hands[i].evaluation;
      const evalP2 = finalPlayerStates[1].hands[i].evaluation;
      if (evalP1 && evalP2) {
        const comparison = (0, import_pokerEvaluator.compareEvaluatedHands)(evalP1, evalP2);
        if (comparison > 0) {
          handEvalResults.p1Wins++;
          handEvalResults.individualWinners[i] = finalPlayerStates[0].id;
        } else if (comparison < 0) {
          handEvalResults.p2Wins++;
          handEvalResults.individualWinners[i] = finalPlayerStates[1].id;
        } else {
          handEvalResults.individualWinners[i] = "Tie";
        }
      } else if (evalP1) {
        handEvalResults.p1Wins++;
        handEvalResults.individualWinners[i] = finalPlayerStates[0].id;
      } else if (evalP2) {
        handEvalResults.p2Wins++;
        handEvalResults.individualWinners[i] = finalPlayerStates[1].id;
      }
    }
    let overallWinnerMsg = "Game Over! ";
    if (handEvalResults.p1Wins > handEvalResults.p2Wins) {
      overallWinnerMsg += `${finalPlayerStates[0].id} wins the game (${handEvalResults.p1Wins} to ${handEvalResults.p2Wins})!`;
    } else if (handEvalResults.p2Wins > handEvalResults.p1Wins) {
      overallWinnerMsg += `${finalPlayerStates[1].id} wins the game (${handEvalResults.p2Wins} to ${handEvalResults.p1Wins})!`;
    } else {
      overallWinnerMsg += `It's a tie overall! (${handEvalResults.p1Wins} to ${handEvalResults.p2Wins})`;
    }
    room.gameState.players = finalPlayerStates;
    room.gameState.gamePhase = "gameOver";
    room.gameState.winnerMessage = overallWinnerMsg;
    room.gameState.individualHandWinners = handEvalResults.individualWinners;
    room.gameState.rematchState = "can_offer";
    room.gameState.rematchAgreedCount = 0;
    room.rematchInfo = {
      requests: {},
      agreedCount: 0,
      offerTimestamp: Date.now()
    };
    io.to(room.id).emit("gameStateUpdate", room.gameState);
    console.log(`Game ${room.id} ended. Winner: ${overallWinnerMsg}. Rematch window open.`);
    clearRoomRematchTimer(room);
    room.rematchInfo.timerId = setTimeout(() => {
      if (rooms.has(room.id) && room.rematchInfo && room.rematchInfo.agreedCount < 2) {
        console.log(`Rematch window for room ${room.id} timed out on server.`);
        io.to(room.id).emit("rematch_offer_expired", { gameId: room.id });
        room.gameState.rematchState = "offer_timed_out";
        room.gameState.rematchAgreedCount = 0;
        io.to(room.id).emit("gameStateUpdate", room.gameState);
        delete room.rematchInfo;
        setTimeout(() => {
          if (rooms.has(room.id) && !room.rematchInfo) {
            rooms.delete(room.id);
            console.log(`Room ${room.id} closed after rematch timeout.`);
          }
        }, 5e3);
      }
    }, REMATCH_WINDOW_MS + 1e3);
  };
  const canPlaceCardInHandServer = (player, handIndex, targetSlot) => {
    if (targetSlot < 0 || targetSlot > 4)
      return false;
    const cardCounts = player.hands.map((h) => h.cards.filter((c) => c !== null).length);
    const cardsInTargetHandCurrently = cardCounts[handIndex];
    if (cardsInTargetHandCurrently !== targetSlot) {
      console.error(`Server validation: Mismatch between targetSlot (${targetSlot}) and actual empty slot count (${cardsInTargetHandCurrently}) in hand ${handIndex} for player ${player.id}.`);
      return false;
    }
    const numCardsTargetHandWillHave = cardsInTargetHandCurrently + 1;
    if (numCardsTargetHandWillHave === 3) {
      return player.hands.every((h) => h.cards.filter((c) => c !== null).length >= 2);
    }
    if (numCardsTargetHandWillHave === 4) {
      return player.hands.every((h) => h.cards.filter((c) => c !== null).length >= 3);
    }
    if (numCardsTargetHandWillHave === 5) {
      return player.hands.every((h) => h.cards.filter((c) => c !== null).length >= 4);
    }
    return true;
  };
  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
    const queueIndex = matchmakingQueue.findIndex((s) => s.id === socket.id);
    if (queueIndex !== -1) {
      matchmakingQueue.splice(queueIndex, 1);
      console.log(`Player ${socket.id} removed from matchmaking queue.`);
    }
    for (const [roomId, room] of rooms.entries()) {
      const playerInRoom = room.players.find((p) => p.socketId === socket.id);
      if (playerInRoom) {
        console.log(`Player ${socket.id} disconnected from room ${roomId}.`);
        clearTurnTimer(room);
        clearRoomRematchTimer(room);
        const otherPlayer = room.players.find((p) => p.socketId !== socket.id);
        if (otherPlayer) {
          io.to(otherPlayer.socketId).emit("opponentDisconnected", "Your opponent has disconnected. Game over.");
          if (room.rematchInfo && room.rematchInfo.agreedCount > 0) {
            io.to(otherPlayer.socketId).emit("rematch_cancelled", { byPlayerId: socket.id });
          }
        }
        rooms.delete(roomId);
        console.log(`Room ${roomId} closed due to disconnect.`);
        break;
      }
    }
  });
  socket.on("request_rematch", ({ gameId, requestingPlayerId }) => {
    const room = rooms.get(gameId);
    if (!room || room.gameState.gamePhase !== "gameOver") {
      socket.emit("error", "Game not found or not over.");
      return;
    }
    if (!room.rematchInfo) {
      socket.emit("error", "Rematch not available for this game.");
      return;
    }
    if (Date.now() - room.rematchInfo.offerTimestamp > REMATCH_WINDOW_MS) {
      io.to(room.id).emit("rematch_offer_expired", { gameId });
      room.gameState.rematchState = "offer_timed_out";
      room.gameState.rematchAgreedCount = 0;
      io.to(room.id).emit("gameStateUpdate", room.gameState);
      clearRoomRematchTimer(room);
      delete room.rematchInfo;
      return;
    }
    if (!room.rematchInfo.requests[requestingPlayerId]) {
      room.rematchInfo.requests[requestingPlayerId] = true;
      room.rematchInfo.agreedCount++;
      room.gameState.rematchAgreedCount = room.rematchInfo.agreedCount;
    }
    console.log(`Player ${requestingPlayerId} requested rematch for game ${gameId}. Agreed: ${room.rematchInfo.agreedCount}`);
    if (room.rematchInfo.agreedCount === 1) {
      const otherPlayerSocketId = room.players.find((p) => p.socketId !== requestingPlayerId)?.socketId;
      if (otherPlayerSocketId) {
        io.to(otherPlayerSocketId).emit("rematch_offer_received", {
          fromPlayerId: requestingPlayerId,
          agreedCount: room.rematchInfo.agreedCount
        });
      }
      socket.emit("rematch_status_update", {
        gameId,
        agreedCount: room.rematchInfo.agreedCount,
        newRematchState: "offer_sent"
        // For the requester
      });
    } else if (room.rematchInfo.agreedCount === 2) {
      console.log(`Both players in room ${gameId} agreed to a rematch.`);
      clearRoomRematchTimer(room);
      const player1Sock = io.sockets.sockets.get(room.players[0].socketId);
      const player2Sock = io.sockets.sockets.get(room.players[1].socketId);
      if (player1Sock && player2Sock) {
        io.to(gameId).emit("rematch_accepted", { gameId });
        const oldRoomId = room.id;
        rooms.delete(oldRoomId);
        console.log(`Old room ${oldRoomId} deleted for rematch.`);
        const newRoom = createNewGame(player1Sock, player2Sock);
        io.to(newRoom.id).emit("gameStart", newRoom.gameState);
        startTurnTimer(newRoom);
      } else {
        console.error("Sockets for rematch not found. Players might have disconnected.");
        if (room)
          rooms.delete(room.id);
      }
    }
  });
  socket.on("cancel_rematch_request", ({ gameId, cancellingPlayerId }) => {
    const room = rooms.get(gameId);
    if (!room || !room.rematchInfo || !room.rematchInfo.requests[cancellingPlayerId]) {
      return;
    }
    room.rematchInfo.requests[cancellingPlayerId] = false;
    room.rematchInfo.agreedCount--;
    room.gameState.rematchAgreedCount = room.rematchInfo.agreedCount;
    socket.emit("rematch_cancelled", { byPlayerId: cancellingPlayerId });
    socket.emit("rematch_status_update", { gameId, agreedCount: room.rematchInfo.agreedCount, newRematchState: "cancelled_by_self" });
    const otherPlayerSocketId = room.players.find((p) => p.socketId !== cancellingPlayerId)?.socketId;
    if (otherPlayerSocketId) {
      io.to(otherPlayerSocketId).emit("rematch_cancelled", { byPlayerId: cancellingPlayerId });
      io.to(otherPlayerSocketId).emit("rematch_status_update", { gameId, agreedCount: room.rematchInfo.agreedCount, newRematchState: "can_offer" });
    }
    console.log(`Player ${cancellingPlayerId} cancelled rematch for game ${gameId}. Agreed: ${room.rematchInfo.agreedCount}`);
  });
  socket.on("decline_rematch", ({ gameId, decliningPlayerId }) => {
    const room = rooms.get(gameId);
    if (!room || !room.rematchInfo) {
      return;
    }
    clearRoomRematchTimer(room);
    console.log(`Player ${decliningPlayerId} declined rematch for game ${gameId}`);
    room.gameState.rematchAgreedCount = 0;
    room.players.forEach((pInfo) => {
      const targetSock = io.sockets.sockets.get(pInfo.socketId);
      if (targetSock) {
        targetSock.emit("rematch_declined", { byPlayerId: decliningPlayerId });
        targetSock.emit("rematch_status_update", {
          gameId,
          agreedCount: 0,
          newRematchState: pInfo.socketId === decliningPlayerId ? "declined_by_self" : "declined_by_opponent"
        });
      }
    });
    delete room.rematchInfo;
    setTimeout(() => {
      if (rooms.has(gameId) && !rooms.get(gameId)?.rematchInfo) {
        rooms.delete(gameId);
        console.log(`Room ${gameId} closed after rematch declined.`);
      }
    }, 5e3);
  });
  socket.on("rematch_timeout", ({ gameId }) => {
    const room = rooms.get(gameId);
    if (room && room.rematchInfo && room.rematchInfo.offerTimestamp) {
      console.log(`Client reported rematch timeout for game ${gameId}. Server timer is authoritative.`);
    }
  });
});
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
