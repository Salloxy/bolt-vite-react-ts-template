var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/cancelMatchmaking.ts
var cancelMatchmaking_exports = {};
__export(cancelMatchmaking_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(cancelMatchmaking_exports);

// server/gameState.ts
var matchmakingQueue = [];

// server/cancelMatchmaking.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { playerId } = payload;
  if (!playerId) {
    return { statusCode: 400, body: "Missing playerId" };
  }
  const index = matchmakingQueue.indexOf(playerId);
  if (index > -1) {
    matchmakingQueue.splice(index, 1);
    console.log(`Player ${playerId} removed from matchmaking queue.`);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Matchmaking cancelled." })
    };
  } else {
    console.log(`Player ${playerId} not found in matchmaking queue for cancellation.`);
    return {
      statusCode: 404,
      // Or 200 with a different message
      body: JSON.stringify({ message: "Player not in queue or already matched." })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
