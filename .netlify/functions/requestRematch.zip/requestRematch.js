var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/requestRematch.ts
var requestRematch_exports = {};
__export(requestRematch_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(requestRematch_exports);

// src/lib/utils.ts
var SUITS = ["H", "D", "C", "S"];
var RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K", "A"];
var createDeck = () => {
  const deck = [];
  for (const suit of SUITS) {
    for (const rank of RANKS) {
      deck.push({ suit, rank, id: `${rank}${suit}` });
    }
  }
  return deck;
};
var shuffleDeck = (deck) => {
  const shuffledDeck = [...deck];
  for (let i = shuffledDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffledDeck[i], shuffledDeck[j]] = [shuffledDeck[j], shuffledDeck[i]];
  }
  return shuffledDeck;
};

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();
var initializePlayerForServer = (id) => ({
  id,
  hands: Array(5).fill(null).map(() => ({ cards: Array(5).fill(null) }))
});
var dealInitialCardsServer = (player, deck) => {
  const newHands = player.hands.map((hand) => {
    const card = deck.pop();
    if (!card) return hand;
    return { ...hand, cards: [{ ...card, hidden: false }, null, null, null, null] };
  });
  return { player: { ...player, hands: newHands }, deck };
};
function createNewGame(player1Id, player2Id) {
  const roomId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  let deck = shuffleDeck(createDeck());
  let p1 = initializePlayerForServer(player1Id);
  let p2 = initializePlayerForServer(player2Id);
  const dealt1 = dealInitialCardsServer(p1, deck);
  p1 = dealt1.player;
  deck = dealt1.deck;
  const dealt2 = dealInitialCardsServer(p2, deck);
  p2 = dealt2.player;
  deck = dealt2.deck;
  const initialGameState = {
    id: roomId,
    deck,
    players: [p1, p2],
    currentPlayerId: player1Id,
    gamePhase: "playing",
    turnNumber: 0,
    placementRuleActive: true,
    heldCard: null
  };
  const room = {
    id: roomId,
    players: [
      { playerId: player1Id, playerNumber: 1 },
      { playerId: player2Id, playerNumber: 2 }
    ],
    gameState: initialGameState,
    rematchRequests: /* @__PURE__ */ new Set()
  };
  rooms.set(roomId, room);
  return room;
}

// server/requestRematch.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { gameId, requestingPlayerId } = payload;
  if (!gameId || !requestingPlayerId) {
    return { statusCode: 400, body: "Missing gameId or requestingPlayerId" };
  }
  const room = rooms.get(gameId);
  if (!room || room.gameState.gamePhase !== "gameOver") {
    return { statusCode: 404, body: "Game not found or not over." };
  }
  if (!room.rematchRequests) {
    room.rematchRequests = /* @__PURE__ */ new Set();
  }
  room.rematchRequests.add(requestingPlayerId);
  room.gameState.rematchAgreedCount = room.rematchRequests.size;
  if (room.rematchRequests.size === 2) {
    const player1Id = room.players[0].playerId;
    const player2Id = room.players[1].playerId;
    rooms.delete(gameId);
    const newRoom = createNewGame(player1Id, player2Id);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Rematch accepted, new game created.",
        newGameId: newRoom.id,
        // Send new game ID
        gameState: newRoom.gameState,
        // Send new game state
        rematchState: "accepted",
        // Explicitly set rematch state
        rematchAgreedCount: newRoom.rematchRequests?.size || 0
      })
    };
  } else {
    room.gameState.rematchState = "offer_sent";
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Rematch request received.",
        gameState: room.gameState,
        // Return current (old) game's updated state
        rematchState: room.gameState.rematchState,
        rematchAgreedCount: room.gameState.rematchAgreedCount
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
