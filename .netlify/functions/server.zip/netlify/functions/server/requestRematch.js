"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { gameId, requestingPlayerId } = payload;
    if (!gameId || !requestingPlayerId) {
        return { statusCode: 400, body: 'Missing gameId or requestingPlayerId' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room || room.gameState.gamePhase !== 'gameOver') {
        return { statusCode: 404, body: 'Game not found or not over.' };
    }
    if (!room.rematchRequests) {
        room.rematchRequests = new Set();
    }
    room.rematchRequests.add(requestingPlayerId);
    room.gameState.rematchAgreedCount = room.rematchRequests.size;
    if (room.rematchRequests.size === 2) {
        const player1Id = room.players[0].playerId;
        const player2Id = room.players[1].playerId;
        gameState_1.rooms.delete(gameId); // Delete old room
        const newRoom = (0, gameState_1.createNewGame)(player1Id, player2Id); // Create new game
        // The new game state is returned, clients will see this and start the new game.
        // The polling on the old gameId will fail (404), client should handle this.
        // Client making the second request will get the new game state.
        // Client making the first request will get updated old game state, then poll into 404, then should re-fetch or be redirected.
        // This part needs careful client-side handling.
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Rematch accepted, new game created.",
                newGameId: newRoom.id, // Send new game ID
                gameState: newRoom.gameState, // Send new game state
                rematchState: 'accepted', // Explicitly set rematch state
                rematchAgreedCount: newRoom.rematchRequests?.size || 0,
            }),
        };
    }
    else {
        // Only one player has requested, update state for polling
        room.gameState.rematchState = 'offer_sent'; // Or 'offer_received' depending on perspective, server sends its view
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Rematch request received.",
                gameState: room.gameState, // Return current (old) game's updated state
                rematchState: room.gameState.rematchState,
                rematchAgreedCount: room.gameState.rematchAgreedCount,
            }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=requestRematch.js.map