"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    const method = event.httpMethod;
    // Accept GET with query parameter or POST with JSON body
    let gameId;
    if (method === 'GET') {
        gameId = event.queryStringParameters?.gameId;
    }
    else if (method === 'POST') {
        try {
            const body = JSON.parse(event.body || '{}');
            gameId = body.gameId;
        }
        catch {
            return { statusCode: 400, body: 'Invalid JSON' };
        }
    }
    else {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    if (!gameId) {
        return { statusCode: 400, body: 'Missing gameId' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room) {
        return { statusCode: 404, body: 'Game not found' };
    }
    return {
        statusCode: 200,
        body: JSON.stringify({ gameState: room.gameState }),
    };
};
exports.handler = handler;
//# sourceMappingURL=getGameState.js.map