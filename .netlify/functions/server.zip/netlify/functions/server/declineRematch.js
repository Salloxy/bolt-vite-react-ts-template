"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { gameId, decliningPlayerId } = payload;
    if (!gameId || !decliningPlayerId) {
        return { statusCode: 400, body: 'Missing gameId or decliningPlayerId' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room) {
        // If room doesn't exist, maybe it was already cleaned up after a timeout or other decline.
        // Client should handle this gracefully.
        return { statusCode: 404, body: 'Game not found or already concluded.' };
    }
    // If game is not over, or rematch already concluded/timed out, this action might be invalid.
    // For simplicity, we'll allow decline even if rematchRequests isn't set, effectively just updating state.
    if (room.gameState.gamePhase !== 'gameOver' && room.gameState.rematchState !== 'offer_sent' && room.gameState.rematchState !== 'offer_received') {
        // It's possible one player declined, and the other tries to decline an already non-existent offer.
        // Or game ended and no offer was made.
        // We can just return the current state or a specific message.
        // For now, let's ensure the state reflects no active rematch.
        room.gameState.rematchState = 'none';
        room.gameState.rematchAgreedCount = 0;
        delete room.rematchRequests; // Clear any lingering requests
        return {
            statusCode: 200, // Or 400 if strict about when decline is valid
            body: JSON.stringify({ message: "No active rematch offer to decline or game not in correct state.", gameState: room.gameState }),
        };
    }
    console.log(`Player ${decliningPlayerId} declined rematch for game ${gameId}`);
    room.gameState.rematchState = 'declined_by_opponent'; // From perspective of the other player
    // If the decliningPlayerId is the one who sent the offer, it's more like 'cancelled_by_self'
    // This logic might need refinement based on who is "declining" vs "cancelling"
    // For now, any decline sets agreed count to 0 and state to reflect a decline.
    room.gameState.rematchAgreedCount = 0;
    if (room.rematchRequests) {
        room.rematchRequests.clear(); // Clear all requests
    }
    // Room could be cleaned up after a short delay by a separate mechanism if desired.
    // For now, the room persists until a new game starts or server cleans it up.
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "Rematch declined.",
            gameState: room.gameState,
            rematchState: room.gameState.rematchState, // Send updated state
            rematchAgreedCount: room.gameState.rematchAgreedCount,
        }),
    };
};
exports.handler = handler;
//# sourceMappingURL=declineRematch.js.map