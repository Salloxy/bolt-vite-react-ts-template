"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.matchmakingQueue = exports.rooms = void 0;
exports.createNewGame = createNewGame;
exports.canPlaceCardInHandServer = canPlaceCardInHandServer;
exports.handleGameEvaluation = handleGameEvaluation;
const utils_1 = require("../src/lib/utils");
const pokerEvaluator_1 = require("../src/lib/pokerEvaluator");
/**
 * Store active game rooms by ID.
 */
exports.rooms = new Map();
/**
 * Queue of player IDs waiting for a match.
 */
exports.matchmakingQueue = [];
/**
 * Create a new empty Player object for the server.
 */
const initializePlayerForServer = (id) => ({
    id,
    hands: Array(5).fill(null).map(() => ({ cards: Array(5).fill(null) })),
});
/**
 * Deal initial cards to a player from the deck.
 */
const dealInitialCardsServer = (player, deck) => {
    const newHands = player.hands.map(hand => {
        const card = deck.pop();
        if (!card)
            return hand;
        // reveal dealt card initially
        return { ...hand, cards: [{ ...card, hidden: false }, null, null, null, null] };
    });
    return { player: { ...player, hands: newHands }, deck };
};
/**
 * Create a new GameRoom with two players, shuffle and deal.
 */
function createNewGame(player1Id, player2Id) {
    const roomId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    let deck = (0, utils_1.shuffleDeck)((0, utils_1.createDeck)());
    let p1 = initializePlayerForServer(player1Id);
    let p2 = initializePlayerForServer(player2Id);
    const dealt1 = dealInitialCardsServer(p1, deck);
    p1 = dealt1.player;
    deck = dealt1.deck;
    const dealt2 = dealInitialCardsServer(p2, deck);
    p2 = dealt2.player;
    deck = dealt2.deck;
    const initialGameState = {
        id: roomId,
        deck,
        players: [p1, p2],
        currentPlayerId: player1Id,
        gamePhase: 'playing',
        turnNumber: 0,
        placementRuleActive: true,
        heldCard: null,
    };
    const room = {
        id: roomId,
        players: [
            { playerId: player1Id, playerNumber: 1 },
            { playerId: player2Id, playerNumber: 2 },
        ],
        gameState: initialGameState,
        rematchRequests: new Set(),
    };
    exports.rooms.set(roomId, room);
    return room;
}
/**
 * Server-side placement validation (mirrors client logic).
 */
function canPlaceCardInHandServer(player, handIndex, targetSlot) {
    if (targetSlot < 0 || targetSlot > 4)
        return false;
    const counts = player.hands.map(h => h.cards.filter(c => c !== null).length);
    if (counts[handIndex] !== targetSlot)
        return false;
    const newCount = counts[handIndex] + 1;
    if (newCount === 3) {
        return counts.every(c => c >= 2);
    }
    if (newCount === 4) {
        return counts.every(c => c >= 3);
    }
    if (newCount === 5) {
        return counts.every(c => c >= 4);
    }
    return true;
}
/**
 * Evaluate a finished game, reveal cards, determine hand and overall winners.
 */
function handleGameEvaluation(room) {
    // Reveal all cards
    room.gameState.players = room.gameState.players.map(player => ({
        ...player,
        hands: player.hands.map(hand => ({
            ...hand,
            cards: hand.cards.map(card => card ? { ...card, hidden: false } : null),
        })),
    }));
    room.gameState.gamePhase = 'evaluation';
    // Evaluate each hand
    const finalPlayers = room.gameState.players.map(p => ({
        ...p,
        hands: p.hands.map(h => ({ ...h, evaluation: (0, pokerEvaluator_1.evaluateHand)(h.cards) })),
    }));
    room.gameState.players = finalPlayers;
    // Compare results
    let p1Wins = 0;
    let p2Wins = 0;
    const individualWinners = Array(5).fill(null);
    for (let i = 0; i < 5; i++) {
        const ev1 = finalPlayers[0].hands[i].evaluation;
        const ev2 = finalPlayers[1].hands[i].evaluation;
        if (ev1 && ev2) {
            const cmp = (0, pokerEvaluator_1.compareEvaluatedHands)(ev1, ev2);
            if (cmp > 0) {
                p1Wins++;
                individualWinners[i] = finalPlayers[0].id;
            }
            else if (cmp < 0) {
                p2Wins++;
                individualWinners[i] = finalPlayers[1].id;
            }
            else {
                individualWinners[i] = 'Tie';
            }
        }
    }
    room.gameState.individualHandWinners = individualWinners;
    room.gameState.winnerMessage = p1Wins > p2Wins
        ? `${finalPlayers[0].id} wins (${p1Wins} to ${p2Wins})`
        : p2Wins > p1Wins
            ? `${finalPlayers[1].id} wins (${p2Wins} to ${p1Wins})`
            : `Tie game (${p1Wins} to ${p2Wins})`;
    room.gameState.gamePhase = 'gameOver';
}
//# sourceMappingURL=gameState.js.map