"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { playerId } = payload;
    if (!playerId) {
        return { statusCode: 400, body: 'Missing playerId' };
    }
    const inQueue = gameState_1.matchmakingQueue.includes(playerId);
    const inGame = Array.from(gameState_1.rooms.values()).some(r => r.players.some(p => p.playerId === playerId));
    if (!inQueue && !inGame) {
        gameState_1.matchmakingQueue.push(playerId);
    }
    if (gameState_1.matchmakingQueue.length >= 2) {
        const p1 = gameState_1.matchmakingQueue.shift();
        const p2 = gameState_1.matchmakingQueue.shift();
        const room = (0, gameState_1.createNewGame)(p1, p2);
        return {
            statusCode: 200,
            body: JSON.stringify({ matched: true, gameId: room.id, gameState: room.gameState })
        };
    }
    return { statusCode: 200, body: JSON.stringify({ matched: false }) };
};
exports.handler = handler;
//# sourceMappingURL=findMatch.js.map