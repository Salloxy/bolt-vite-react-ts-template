"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { gameId, cancellingPlayerId } = payload;
    if (!gameId || !cancellingPlayerId) {
        return { statusCode: 400, body: 'Missing gameId or cancellingPlayerId' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room || !room.rematchRequests || !room.rematchRequests.has(cancellingPlayerId)) {
        // If no room, no requests, or player hadn't requested, this action is moot.
        return {
            statusCode: 400,
            body: JSON.stringify({ message: "No active rematch request to cancel for this player or game not found.", gameState: room?.gameState })
        };
    }
    console.log(`Player ${cancellingPlayerId} cancelled rematch request for game ${gameId}`);
    room.rematchRequests.delete(cancellingPlayerId);
    room.gameState.rematchAgreedCount = room.rematchRequests.size;
    // If count is 0, set state to can_offer or none. If 1, other player is still 'offer_received' or 'offer_sent'.
    // Server should determine the correct overall rematchState.
    // For simplicity, if a cancellation happens, we might just revert to 'can_offer' if game is over.
    if (room.gameState.gamePhase === 'gameOver') {
        room.gameState.rematchState = room.rematchRequests.size > 0 ? 'offer_sent' : 'can_offer';
    }
    else {
        room.gameState.rematchState = 'none'; // Should not happen if game not over
    }
    return {
        statusCode: 200,
        body: JSON.stringify({
            message: "Rematch request cancelled.",
            gameState: room.gameState,
            rematchState: room.gameState.rematchState,
            rematchAgreedCount: room.gameState.rematchAgreedCount,
        }),
    };
};
exports.handler = handler;
//# sourceMappingURL=cancelRematch.js.map