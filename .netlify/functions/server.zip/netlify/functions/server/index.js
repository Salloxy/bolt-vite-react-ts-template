"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// server/index.ts
var express_1 = __importDefault(require("express"));
var http_1 = __importDefault(require("http"));
var socket_io_1 = require("socket.io");
var utils_1 = require("../src/lib/utils"); // Assuming utils can be shared
var pokerEvaluator_1 = require("../src/lib/pokerEvaluator"); // Assuming evaluator can be shared
var app = (0, express_1.default)();
var server = http_1.default.createServer(app);
var io = new socket_io_1.Server(server, {
    cors: {
        origin: "http://localhost:5173", // Vite dev server default
        methods: ["GET", "POST"]
    }
});
var PORT = process.env.PORT || 3000;
var REMATCH_WINDOW_MS = 10000; // 10 seconds for rematch window
var rooms = new Map();
var matchmakingQueue = [];
var initializePlayerForServer = function (id) { return ({
    id: id,
    hands: Array(5).fill(null).map(function () { return ({ cards: Array(5).fill(null) }); }),
}); };
var createNewGame = function (player1Socket, player2Socket) {
    var roomId = "game_".concat(Date.now(), "_").concat(Math.random().toString(36).substring(2, 7));
    var player1ServerObj = initializePlayerForServer(player1Socket.id);
    var player2ServerObj = initializePlayerForServer(player2Socket.id);
    var serverDeck = (0, utils_1.shuffleDeck)((0, utils_1.createDeck)());
    // Helper function to deal initial cards on server
    var dealInitialCardsServer = function (player, currentDeck) {
        var updatedPlayerHands = player.hands.map(function (hand) {
            var cardToDeal = currentDeck.pop();
            // Ensure cards dealt initially are not hidden
            var dealtCard = cardToDeal ? __assign(__assign({}, cardToDeal), { hidden: false }) : null;
            return dealtCard ? __assign(__assign({}, hand), { cards: [dealtCard, null, null, null, null] }) : hand;
        });
        return { updatedPlayer: __assign(__assign({}, player), { hands: updatedPlayerHands }), updatedDeck: currentDeck };
    };
    var p1Result = dealInitialCardsServer(player1ServerObj, serverDeck);
    player1ServerObj = p1Result.updatedPlayer;
    serverDeck = p1Result.updatedDeck;
    var p2Result = dealInitialCardsServer(player2ServerObj, serverDeck);
    player2ServerObj = p2Result.updatedPlayer;
    serverDeck = p2Result.updatedDeck;
    var initialGameState = {
        id: roomId,
        deck: serverDeck,
        players: [player1ServerObj, player2ServerObj],
        currentPlayerId: player1Socket.id, // Player 1 (first to connect to match) starts
        gamePhase: 'playing', // Start directly in playing phase after initial deal
        turnNumber: 0,
        placementRuleActive: true,
        heldCard: null,
    };
    var room = {
        id: roomId,
        players: [
            { socketId: player1Socket.id, playerNumber: 1 },
            { socketId: player2Socket.id, playerNumber: 2 }
        ],
        gameState: initialGameState,
        turnTimerDuration: 30000, // 30 seconds
    };
    rooms.set(roomId, room);
    player1Socket.join(roomId);
    player2Socket.join(roomId);
    console.log("Game room ".concat(roomId, " created for ").concat(player1Socket.id, " and ").concat(player2Socket.id));
    return room;
};
io.on('connection', function (socket) {
    console.log('A user connected:', socket.id);
    var clearTurnTimer = function (room) {
        if (room.turnTimerId) {
            clearTimeout(room.turnTimerId);
            delete room.turnTimerId;
        }
        delete room.gameState.turnStartTime;
        delete room.gameState.turnTimerEndsAt;
    };
    var startTurnTimer = function (room) {
        clearTurnTimer(room); // Clear any existing timer first
        if (room.gameState.gamePhase !== 'playing' || !room.gameState.currentPlayerId) {
            return; // Don't start timer if game is not in playing phase or no current player
        }
        var currentPlayerSocketId = room.gameState.currentPlayerId;
        room.gameState.turnStartTime = Date.now();
        room.gameState.turnTimerEndsAt = Date.now() + room.turnTimerDuration;
        console.log("Starting turn timer (".concat(room.turnTimerDuration / 1000, "s) for player ").concat(currentPlayerSocketId, " in room ").concat(room.id));
        room.turnTimerId = setTimeout(function () {
            if (!rooms.has(room.id) || room.gameState.currentPlayerId !== currentPlayerSocketId) {
                // Room might have been deleted or player changed due to other actions
                return;
            }
            console.log("Turn timer expired for player ".concat(currentPlayerSocketId, " in room ").concat(room.id));
            var timedOutPlayerSocket = io.sockets.sockets.get(currentPlayerSocketId);
            if (timedOutPlayerSocket) {
                timedOutPlayerSocket.emit('turnTimeout', { gameId: room.id, playerId: currentPlayerSocketId });
                // Client will handle redirect to homepage. Server just moves to next player.
            }
            // Switch to next player
            var currentPlayerIndex = room.players.findIndex(function (p) { return p.socketId === currentPlayerSocketId; });
            var nextPlayerIndex = (currentPlayerIndex + 1) % room.players.length;
            room.gameState.currentPlayerId = room.players[nextPlayerIndex].socketId;
            room.gameState.turnNumber++; // Increment turn number
            room.gameState.heldCard = null; // Ensure no card is held by the new current player initially
            console.log("Switched to player ".concat(room.gameState.currentPlayerId, " due to timeout in room ").concat(room.id));
            startTurnTimer(room); // Start timer for the new player
            io.to(room.id).emit('gameStateUpdate', room.gameState);
        }, room.turnTimerDuration);
        // Broadcast the updated game state so clients know about the timer
        io.to(room.id).emit('gameStateUpdate', room.gameState);
    };
    var clearRoomRematchTimer = function (room) {
        var _a;
        if ((_a = room.rematchInfo) === null || _a === void 0 ? void 0 : _a.timerId) {
            clearTimeout(room.rematchInfo.timerId);
            delete room.rematchInfo.timerId;
        }
    };
    socket.on('findMatch', function () {
        console.log("Player ".concat(socket.id, " is looking for a match."));
        // Ensure player is not already in queue or a game
        if (matchmakingQueue.find(function (s) { return s.id === socket.id; }) || Array.from(rooms.values()).find(function (r) { return r.players.some(function (p) { return p.socketId === socket.id; }); })) {
            socket.emit('error', 'Already in queue or game.');
            return;
        }
        matchmakingQueue.push(socket);
        if (matchmakingQueue.length >= 2) {
            var player1 = matchmakingQueue.shift();
            var player2 = matchmakingQueue.shift();
            var room = createNewGame(player1, player2);
            // Notify players about the game start
            io.to(room.id).emit('gameStart', room.gameState);
            startTurnTimer(room); // Start timer for the first player
            // player1.emit('assignPlayerId', player1.id); // Client already uses socket.id
            // player2.emit('assignPlayerId', player2.id);
        }
        else {
            socket.emit('message', 'Waiting for another player...');
        }
    });
    socket.on('drawCard', function (_a) {
        var _b;
        var gameId = _a.gameId, playerId = _a.playerId;
        var room = rooms.get(gameId);
        if (!room || room.gameState.currentPlayerId !== playerId || room.gameState.heldCard) {
            socket.emit('error', 'Invalid action or not your turn or card already held.');
            return;
        }
        if (room.gameState.deck.length === 0) {
            socket.emit('error', 'Deck is empty.');
            return;
        }
        // clearTurnTimer(room); // Pause timer while card is held <-- REMOVED THIS LINE
        var drawnCard = room.gameState.deck.pop();
        room.gameState.heldCard = drawnCard;
        // Notify only the current player about the card they drew
        socket.emit('playerDrewCard', { card: drawnCard });
        // Broadcast updated game state (deck change, heldCard status for current player)
        // For simplicity, we can send the whole state, or specific updates.
        // To hide heldCard from opponent, we need to send tailored states.
        // Send full state to current player
        socket.emit('gameStateUpdate', room.gameState);
        // Send state to opponent, masking current player's held card
        var opponentSocketId = (_b = room.players.find(function (p) { return p.socketId !== playerId; })) === null || _b === void 0 ? void 0 : _b.socketId;
        if (opponentSocketId) {
            var opponentGameState = JSON.parse(JSON.stringify(room.gameState));
            if (opponentGameState.currentPlayerId === playerId) {
                opponentGameState.heldCard = null; // Mask for opponent
            }
            io.to(opponentSocketId).emit('gameStateUpdate', opponentGameState);
        }
        console.log("Player ".concat(playerId, " in room ").concat(gameId, " drew ").concat(drawnCard.id));
    });
    socket.on('placeCard', function (_a) {
        var gameId = _a.gameId, playerId = _a.playerId, handIndex = _a.handIndex, card = _a.card;
        var room = rooms.get(gameId);
        if (!room || room.gameState.currentPlayerId !== playerId || !room.gameState.heldCard || room.gameState.heldCard.id !== card.id) {
            socket.emit('error', 'Invalid action, not your turn, or card mismatch.');
            return;
        }
        clearTurnTimer(room); // Player made an action, clear their current turn timer
        var playerState = room.gameState.players.find(function (p) { return p.id === playerId; });
        if (!playerState)
            return;
        var targetHand = playerState.hands[handIndex];
        if (!targetHand) {
            socket.emit('error', "Invalid hand index.");
            return;
        }
        var firstEmptySlot = targetHand.cards.findIndex(function (c) { return c === null; });
        if (firstEmptySlot === -1) {
            socket.emit('error', "Hand is full.");
            return;
        }
        // Server-side validation of placement
        if (!canPlaceCardInHandServer(playerState, handIndex, firstEmptySlot)) {
            socket.emit('error', "Placement restriction: Cannot place card in this hand yet.");
            return;
        }
        targetHand.cards[firstEmptySlot] = card;
        if (firstEmptySlot === 4) {
            targetHand.cards[firstEmptySlot].hidden = true;
        }
        room.gameState.heldCard = null;
        // Check for game end
        var allHandsFull = room.gameState.players.every(function (p) {
            return p.hands.every(function (h) { return h.cards.filter(function (c) { return c !== null; }).length === 5; });
        });
        if (allHandsFull) {
            room.gameState.gamePhase = 'evaluation';
            clearTurnTimer(room); // Game is over, no more turns
        }
        else {
            var currentPlayerIndex = room.players.findIndex(function (p) { return p.socketId === playerId; });
            room.gameState.currentPlayerId = room.players[(currentPlayerIndex + 1) % room.players.length].socketId;
            room.gameState.turnNumber++;
            startTurnTimer(room); // Start timer for the next player
        }
        io.to(gameId).emit('gameStateUpdate', room.gameState); // This will now include timer info if a new turn started
        console.log("Player ".concat(playerId, " in room ").concat(gameId, " placed ").concat(card.id, " in hand ").concat(handIndex));
        if (room.gameState.gamePhase === 'evaluation') {
            // Trigger evaluation directly or emit an event for it
            handleGameEvaluation(room);
        }
    });
    var handleGameEvaluation = function (room) {
        clearTurnTimer(room); // Ensure no turn timer is running during evaluation/game over
        console.log("Evaluating game ".concat(room.id));
        var playersWithRevealedCards = room.gameState.players.map(function (player) { return (__assign(__assign({}, player), { hands: player.hands.map(function (hand) { return (__assign(__assign({}, hand), { cards: hand.cards.map(function (card) { return card ? __assign(__assign({}, card), { hidden: false }) : null; }) })); }) })); });
        var handEvalResults = {
            p1Wins: 0,
            p2Wins: 0,
            individualWinners: Array(5).fill(null),
        };
        var finalPlayerStates = playersWithRevealedCards.map(function (p) { return (__assign(__assign({}, p), { hands: p.hands.map(function (h) { return (__assign(__assign({}, h), { evaluation: (0, pokerEvaluator_1.evaluateHand)(h.cards) })); }) })); });
        for (var i = 0; i < 5; i++) {
            var evalP1 = finalPlayerStates[0].hands[i].evaluation;
            var evalP2 = finalPlayerStates[1].hands[i].evaluation;
            if (evalP1 && evalP2) {
                var comparison = (0, pokerEvaluator_1.compareEvaluatedHands)(evalP1, evalP2);
                if (comparison > 0) {
                    handEvalResults.p1Wins++;
                    handEvalResults.individualWinners[i] = finalPlayerStates[0].id;
                }
                else if (comparison < 0) {
                    handEvalResults.p2Wins++;
                    handEvalResults.individualWinners[i] = finalPlayerStates[1].id;
                }
                else {
                    handEvalResults.individualWinners[i] = 'Tie';
                }
            }
            else if (evalP1) {
                handEvalResults.p1Wins++;
                handEvalResults.individualWinners[i] = finalPlayerStates[0].id;
            }
            else if (evalP2) {
                handEvalResults.p2Wins++;
                handEvalResults.individualWinners[i] = finalPlayerStates[1].id;
            }
        }
        var overallWinnerMsg = "Game Over! ";
        if (handEvalResults.p1Wins > handEvalResults.p2Wins) {
            overallWinnerMsg += "".concat(finalPlayerStates[0].id, " wins the game (").concat(handEvalResults.p1Wins, " to ").concat(handEvalResults.p2Wins, ")!");
        }
        else if (handEvalResults.p2Wins > handEvalResults.p1Wins) {
            overallWinnerMsg += "".concat(finalPlayerStates[1].id, " wins the game (").concat(handEvalResults.p2Wins, " to ").concat(handEvalResults.p1Wins, ")!");
        }
        else {
            overallWinnerMsg += "It's a tie overall! (".concat(handEvalResults.p1Wins, " to ").concat(handEvalResults.p2Wins, ")");
        }
        room.gameState.players = finalPlayerStates;
        room.gameState.gamePhase = 'gameOver';
        room.gameState.winnerMessage = overallWinnerMsg;
        room.gameState.individualHandWinners = handEvalResults.individualWinners;
        room.gameState.rematchState = 'can_offer'; // Game just ended, rematch can be offered
        room.gameState.rematchAgreedCount = 0; // No one has agreed yet
        // Initialize rematch info on the server-side room object
        room.rematchInfo = {
            requests: {},
            agreedCount: 0,
            offerTimestamp: Date.now(),
        };
        io.to(room.id).emit('gameStateUpdate', room.gameState); // Send final game state with rematch info
        console.log("Game ".concat(room.id, " ended. Winner: ").concat(overallWinnerMsg, ". Rematch window open."));
        // Set a server-side timer to handle rematch window timeout
        clearRoomRematchTimer(room); // Clear any existing timer for this room
        room.rematchInfo.timerId = setTimeout(function () {
            if (rooms.has(room.id) && room.rematchInfo && room.rematchInfo.agreedCount < 2) {
                console.log("Rematch window for room ".concat(room.id, " timed out on server."));
                io.to(room.id).emit('rematch_offer_expired', { gameId: room.id });
                // Update gameState to reflect timeout
                room.gameState.rematchState = 'offer_timed_out';
                room.gameState.rematchAgreedCount = 0;
                io.to(room.id).emit('gameStateUpdate', room.gameState); // Notify clients
                delete room.rematchInfo; // Clean up rematch specific info
                // Decide on further room cleanup, e.g., delete after another short delay
                setTimeout(function () {
                    if (rooms.has(room.id) && !room.rematchInfo) { // Only delete if no new rematch process started
                        rooms.delete(room.id);
                        console.log("Room ".concat(room.id, " closed after rematch timeout."));
                    }
                }, 5000); // Short delay before closing room fully
            }
        }, REMATCH_WINDOW_MS + 1000); // Give a little buffer
    };
    // Server-side equivalent of canPlaceCardInHand from useGameLogic
    var canPlaceCardInHandServer = function (player, handIndex, targetSlot) {
        if (targetSlot < 0 || targetSlot > 4)
            return false;
        var cardCounts = player.hands.map(function (h) { return h.cards.filter(function (c) { return c !== null; }).length; });
        var cardsInTargetHandCurrently = cardCounts[handIndex];
        if (cardsInTargetHandCurrently !== targetSlot) {
            // This implies we are not filling the next available slot sequentially.
            // This check is crucial on the server.
            console.error("Server validation: Mismatch between targetSlot (".concat(targetSlot, ") and actual empty slot count (").concat(cardsInTargetHandCurrently, ") in hand ").concat(handIndex, " for player ").concat(player.id, "."));
            return false;
        }
        var numCardsTargetHandWillHave = cardsInTargetHandCurrently + 1;
        if (numCardsTargetHandWillHave === 3) { // Placing the 3rd card
            return player.hands.every(function (h) { return h.cards.filter(function (c) { return c !== null; }).length >= 2; });
        }
        if (numCardsTargetHandWillHave === 4) { // Placing the 4th card
            return player.hands.every(function (h) { return h.cards.filter(function (c) { return c !== null; }).length >= 3; });
        }
        if (numCardsTargetHandWillHave === 5) { // Placing the 5th card
            return player.hands.every(function (h) { return h.cards.filter(function (c) { return c !== null; }).length >= 4; });
        }
        return true;
    };
    // This was in useGameLogic, server should handle it if game is online
    // socket.on('evaluateGame', ({ gameId }: { gameId: string }) => {
    //   const room = rooms.get(gameId);
    //   if (room) {
    //     handleGameEvaluation(room);
    //   }
    // });
    socket.on('disconnect', function () {
        console.log('User disconnected:', socket.id);
        // Remove from queue if present
        var queueIndex = matchmakingQueue.findIndex(function (s) { return s.id === socket.id; });
        if (queueIndex !== -1) {
            matchmakingQueue.splice(queueIndex, 1);
            console.log("Player ".concat(socket.id, " removed from matchmaking queue."));
        }
        // Handle disconnects from active games
        for (var _i = 0, _a = rooms.entries(); _i < _a.length; _i++) {
            var _b = _a[_i], roomId = _b[0], room = _b[1];
            var playerInRoom = room.players.find(function (p) { return p.socketId === socket.id; });
            if (playerInRoom) {
                console.log("Player ".concat(socket.id, " disconnected from room ").concat(roomId, "."));
                clearTurnTimer(room); // Clear turn timer if active
                clearRoomRematchTimer(room); // Clear rematch timer if active
                // Notify other player
                var otherPlayer = room.players.find(function (p) { return p.socketId !== socket.id; });
                if (otherPlayer) {
                    io.to(otherPlayer.socketId).emit('opponentDisconnected', 'Your opponent has disconnected. Game over.');
                    // If a rematch was in progress, notify the other player it's cancelled due to disconnect
                    if (room.rematchInfo && room.rematchInfo.agreedCount > 0) {
                        io.to(otherPlayer.socketId).emit('rematch_cancelled', { byPlayerId: socket.id });
                    }
                }
                // Clean up room
                rooms.delete(roomId);
                console.log("Room ".concat(roomId, " closed due to disconnect."));
                break;
            }
        }
    });
    socket.on('request_rematch', function (_a) {
        var _b;
        var gameId = _a.gameId, requestingPlayerId = _a.requestingPlayerId;
        var room = rooms.get(gameId);
        if (!room || room.gameState.gamePhase !== 'gameOver') {
            socket.emit('error', 'Game not found or not over.');
            return;
        }
        if (!room.rematchInfo) { // Rematch window might have closed or not initialized
            socket.emit('error', 'Rematch not available for this game.');
            // Optionally send an offer_timed_out if appropriate
            // socket.emit('rematch_offer_expired', { gameId });
            return;
        }
        if (Date.now() - room.rematchInfo.offerTimestamp > REMATCH_WINDOW_MS) {
            io.to(room.id).emit('rematch_offer_expired', { gameId: gameId });
            room.gameState.rematchState = 'offer_timed_out';
            room.gameState.rematchAgreedCount = 0;
            io.to(room.id).emit('gameStateUpdate', room.gameState);
            clearRoomRematchTimer(room);
            delete room.rematchInfo;
            return;
        }
        if (!room.rematchInfo.requests[requestingPlayerId]) {
            room.rematchInfo.requests[requestingPlayerId] = true;
            room.rematchInfo.agreedCount++;
            room.gameState.rematchAgreedCount = room.rematchInfo.agreedCount; // Update gameState field
        }
        console.log("Player ".concat(requestingPlayerId, " requested rematch for game ").concat(gameId, ". Agreed: ").concat(room.rematchInfo.agreedCount));
        if (room.rematchInfo.agreedCount === 1) {
            // First player to agree. Notify the other player they received an offer.
            var otherPlayerSocketId = (_b = room.players.find(function (p) { return p.socketId !== requestingPlayerId; })) === null || _b === void 0 ? void 0 : _b.socketId;
            if (otherPlayerSocketId) {
                io.to(otherPlayerSocketId).emit('rematch_offer_received', {
                    fromPlayerId: requestingPlayerId,
                    agreedCount: room.rematchInfo.agreedCount
                });
            }
            // Notify the requester that their offer is sent (client already does this optimistically)
            // We can send a status update to confirm.
            socket.emit('rematch_status_update', {
                gameId: gameId,
                agreedCount: room.rematchInfo.agreedCount,
                newRematchState: 'offer_sent' // For the requester
            });
        }
        else if (room.rematchInfo.agreedCount === 2) {
            console.log("Both players in room ".concat(gameId, " agreed to a rematch."));
            clearRoomRematchTimer(room); // Stop the timeout timer
            var player1Sock = io.sockets.sockets.get(room.players[0].socketId);
            var player2Sock = io.sockets.sockets.get(room.players[1].socketId);
            if (player1Sock && player2Sock) {
                io.to(gameId).emit('rematch_accepted', { gameId: gameId }); // Notify clients rematch is fully accepted
                var oldRoomId = room.id;
                rooms.delete(oldRoomId); // Delete the old room
                console.log("Old room ".concat(oldRoomId, " deleted for rematch."));
                var newRoom = createNewGame(player1Sock, player2Sock);
                io.to(newRoom.id).emit('gameStart', newRoom.gameState);
                startTurnTimer(newRoom); // Start timer for the new game
            }
            else {
                console.error('Sockets for rematch not found. Players might have disconnected.');
                // If one disconnected, the disconnect handler should clean up.
                // If both somehow disconnected right at this moment, this branch might be hit.
                if (room)
                    rooms.delete(room.id); // Clean up the room if it still exists
            }
        }
    });
    socket.on('cancel_rematch_request', function (_a) {
        var _b;
        var gameId = _a.gameId, cancellingPlayerId = _a.cancellingPlayerId;
        var room = rooms.get(gameId);
        if (!room || !room.rematchInfo || !room.rematchInfo.requests[cancellingPlayerId]) {
            return;
        }
        room.rematchInfo.requests[cancellingPlayerId] = false;
        room.rematchInfo.agreedCount--;
        room.gameState.rematchAgreedCount = room.rematchInfo.agreedCount;
        // Notify self of cancellation success
        socket.emit('rematch_cancelled', { byPlayerId: cancellingPlayerId });
        socket.emit('rematch_status_update', { gameId: gameId, agreedCount: room.rematchInfo.agreedCount, newRematchState: 'cancelled_by_self' });
        // Notify other player
        var otherPlayerSocketId = (_b = room.players.find(function (p) { return p.socketId !== cancellingPlayerId; })) === null || _b === void 0 ? void 0 : _b.socketId;
        if (otherPlayerSocketId) {
            io.to(otherPlayerSocketId).emit('rematch_cancelled', { byPlayerId: cancellingPlayerId });
            // Other player might revert to 'can_offer' or 'none' depending on server logic / client interpretation
            io.to(otherPlayerSocketId).emit('rematch_status_update', { gameId: gameId, agreedCount: room.rematchInfo.agreedCount, newRematchState: 'can_offer' }); // Or 'none'
        }
        console.log("Player ".concat(cancellingPlayerId, " cancelled rematch for game ").concat(gameId, ". Agreed: ").concat(room.rematchInfo.agreedCount));
    });
    socket.on('decline_rematch', function (_a) {
        var gameId = _a.gameId, decliningPlayerId = _a.decliningPlayerId;
        var room = rooms.get(gameId);
        if (!room || !room.rematchInfo) {
            return;
        }
        clearRoomRematchTimer(room); // Stop rematch timeout
        console.log("Player ".concat(decliningPlayerId, " declined rematch for game ").concat(gameId));
        room.gameState.rematchAgreedCount = 0; // Reset agreed count
        // Notify both players of the decline
        room.players.forEach(function (pInfo) {
            var targetSock = io.sockets.sockets.get(pInfo.socketId);
            if (targetSock) {
                targetSock.emit('rematch_declined', { byPlayerId: decliningPlayerId });
                targetSock.emit('rematch_status_update', {
                    gameId: gameId,
                    agreedCount: 0,
                    newRematchState: pInfo.socketId === decliningPlayerId ? 'declined_by_self' : 'declined_by_opponent'
                });
            }
        });
        delete room.rematchInfo; // Rematch process ended
        // Room can be cleaned up after a short delay
        setTimeout(function () {
            var _a;
            if (rooms.has(gameId) && !((_a = rooms.get(gameId)) === null || _a === void 0 ? void 0 : _a.rematchInfo)) { // ensure no new rematch started
                rooms.delete(gameId);
                console.log("Room ".concat(gameId, " closed after rematch declined."));
            }
        }, 5000);
    });
    socket.on('rematch_timeout', function (_a) {
        var gameId = _a.gameId;
        var room = rooms.get(gameId);
        if (room && room.rematchInfo && room.rematchInfo.offerTimestamp) {
            // This event is client-reported, server has its own authoritative timer.
            // We can log it, but server's timer in handleGameEvaluation is the source of truth for cleanup.
            console.log("Client reported rematch timeout for game ".concat(gameId, ". Server timer is authoritative."));
            // If server timer hasn't fired, this client report might be early or redundant.
            // Server will emit 'rematch_offer_expired' when its own timer fires.
        }
    });
});
server.listen(PORT, function () {
    console.log("Server listening on port ".concat(PORT));
});
//# sourceMappingURL=index.js.map