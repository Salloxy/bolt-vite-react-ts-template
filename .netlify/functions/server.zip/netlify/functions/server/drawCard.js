"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { gameId, playerId } = payload;
    if (!gameId || !playerId) {
        return { statusCode: 400, body: 'Missing gameId or playerId' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room) {
        return { statusCode: 404, body: 'Game not found' };
    }
    if (room.gameState.currentPlayerId !== playerId || room.gameState.heldCard) {
        return { statusCode: 400, body: 'Invalid action or not your turn or card already held' };
    }
    if (room.gameState.deck.length === 0) {
        return { statusCode: 400, body: 'Deck is empty' };
    }
    const drawnCard = room.gameState.deck.pop();
    room.gameState.heldCard = drawnCard;
    return {
        statusCode: 200,
        body: JSON.stringify({ gameState: room.gameState })
    };
};
exports.handler = handler;
//# sourceMappingURL=drawCard.js.map