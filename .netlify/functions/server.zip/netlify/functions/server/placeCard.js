"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { gameId, playerId, handIndex, card } = payload;
    if (!gameId || !playerId || handIndex === undefined || !card) {
        return { statusCode: 400, body: 'Missing gameId, playerId, handIndex, or card' };
    }
    const room = gameState_1.rooms.get(gameId);
    if (!room) {
        return { statusCode: 404, body: 'Game not found' };
    }
    if (room.gameState.currentPlayerId !== playerId || !room.gameState.heldCard || room.gameState.heldCard.id !== card.id) {
        return { statusCode: 400, body: 'Invalid action, not your turn, or card mismatch.' };
    }
    const playerState = room.gameState.players.find(p => p.id === playerId);
    if (!playerState) {
        return { statusCode: 404, body: 'Player not found in game' };
    }
    const targetHand = playerState.hands[handIndex];
    if (!targetHand) {
        return { statusCode: 400, body: 'Invalid hand index.' };
    }
    const firstEmptySlot = targetHand.cards.findIndex(c => c === null);
    if (firstEmptySlot === -1) {
        return { statusCode: 400, body: 'Hand is full.' };
    }
    if (!(0, gameState_1.canPlaceCardInHandServer)(playerState, handIndex, firstEmptySlot)) {
        return { statusCode: 400, body: 'Placement restriction: Cannot place card in this hand yet.' };
    }
    targetHand.cards[firstEmptySlot] = card;
    if (firstEmptySlot === 4) { // Last card in hand
        targetHand.cards[firstEmptySlot].hidden = true; // Server marks it hidden, client will unhide for self
    }
    room.gameState.heldCard = null;
    const allHandsFull = room.gameState.players.every(p => p.hands.every(h => h.cards.filter(c => c !== null).length === 5));
    if (allHandsFull) {
        room.gameState.gamePhase = 'evaluation';
        (0, gameState_1.handleGameEvaluation)(room); // This will set phase to 'gameOver'
    }
    else {
        const currentPlayerIndex = room.players.findIndex(p => p.playerId === playerId);
        room.gameState.currentPlayerId = room.players[(currentPlayerIndex + 1) % room.players.length].playerId;
        room.gameState.turnNumber++;
    }
    return {
        statusCode: 200,
        body: JSON.stringify({ gameState: room.gameState }),
    };
};
exports.handler = handler;
//# sourceMappingURL=placeCard.js.map