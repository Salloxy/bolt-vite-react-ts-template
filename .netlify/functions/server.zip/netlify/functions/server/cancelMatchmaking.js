"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const gameState_1 = require("./gameState");
const handler = async (event) => {
    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, body: 'Method Not Allowed' };
    }
    let payload;
    try {
        payload = JSON.parse(event.body || '{}');
    }
    catch {
        return { statusCode: 400, body: 'Invalid JSON' };
    }
    const { playerId } = payload;
    if (!playerId) {
        return { statusCode: 400, body: 'Missing playerId' };
    }
    const index = gameState_1.matchmakingQueue.indexOf(playerId);
    if (index > -1) {
        gameState_1.matchmakingQueue.splice(index, 1);
        console.log(`Player ${playerId} removed from matchmaking queue.`);
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Matchmaking cancelled." }),
        };
    }
    else {
        console.log(`Player ${playerId} not found in matchmaking queue for cancellation.`);
        return {
            statusCode: 404, // Or 200 with a different message
            body: JSON.stringify({ message: "Player not in queue or already matched." }),
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=cancelMatchmaking.js.map