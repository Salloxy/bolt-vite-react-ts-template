var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/drawCard.ts
var drawCard_exports = {};
__export(drawCard_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(drawCard_exports);

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();

// server/drawCard.ts
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  const { gameId, playerId } = payload;
  if (!gameId || !playerId) {
    return { statusCode: 400, body: "Missing gameId or playerId" };
  }
  const room = rooms.get(gameId);
  if (!room) {
    return { statusCode: 404, body: "Game not found" };
  }
  if (room.gameState.currentPlayerId !== playerId || room.gameState.heldCard) {
    return { statusCode: 400, body: "Invalid action or not your turn or card already held" };
  }
  if (room.gameState.deck.length === 0) {
    return { statusCode: 400, body: "Deck is empty" };
  }
  const drawnCard = room.gameState.deck.pop();
  room.gameState.heldCard = drawnCard;
  return {
    statusCode: 200,
    body: JSON.stringify({ gameState: room.gameState })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
