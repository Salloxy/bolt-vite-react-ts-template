var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/getGameState.ts
var getGameState_exports = {};
__export(getGameState_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(getGameState_exports);

// server/gameState.ts
var rooms = /* @__PURE__ */ new Map();

// server/getGameState.ts
var handler = async (event) => {
  const method = event.httpMethod;
  let gameId;
  if (method === "GET") {
    gameId = event.queryStringParameters?.gameId;
  } else if (method === "POST") {
    try {
      const body = JSON.parse(event.body || "{}");
      gameId = body.gameId;
    } catch {
      return { statusCode: 400, body: "Invalid JSON" };
    }
  } else {
    return { statusCode: 405, body: "Method Not Allowed" };
  }
  if (!gameId) {
    return { statusCode: 400, body: "Missing gameId" };
  }
  const room = rooms.get(gameId);
  if (!room) {
    return { statusCode: 404, body: "Game not found" };
  }
  return {
    statusCode: 200,
    body: JSON.stringify({ gameState: room.gameState })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
